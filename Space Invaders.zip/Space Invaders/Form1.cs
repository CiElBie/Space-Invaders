﻿using System;
using System.Threading;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Invaders
{
    public partial class Form1 : Form
    {
        /*
         * add red invader
         */

        Keys keydown; //stores the recent key that was pressed down
        Keys keyup; //stores the key that was just released
        bool keyleft = false; //if the left key has been pressed or unpressed
        bool keyright = false; //if the right key has been pressed or unpressed
        bool keyspace = false; //if the right key has been pressed or unpressed
        int[,] Invaders = new int[10, 5]; //array for the invaders
        int[,] Shield = new int[10, 4];//array for the shield
        int[] Shielddam = new int[40];  //array for how much damage each part of the shield has taken
        int Shieldindex;  //used to tell which shield part we are on
        Brush colour;  //sets the colour of the invaders based on value
        Brush Shieldcolour;  //sets the colour of the shield based on damage
        int InvaderIndex; //stores which invader we are on in the array
        bool[] InTrue = new bool[50];  //array for storing if the invaders are real
        bool[] InBull = new bool[50];  //array for storing if the invaders have bullet
        int[] invbully = new int[50];  //array that stores each invader bullets y coordinate
        int[] invbullx = new int[50];  //array that stores each invader bullets x coordinate
        int trix; //stores the x coordinate of the triangles in the shield
        int triy;  //stores the y coordinate of the triangle in the shield
        int bulletx; //bullets x coordinate
        int bullety; //bullets y coordinate
        int shieldx; //shield x coordinate
        int shieldy; //shield y coordinate
        bool triangle; //if the shield is a triangle
        int currentinvaderx;  //stores the x coordinate of the invader
        int currentinvadery;  //stores the y coordinate of the invader
        int pointsearned;  //stores the points earned from killing each invader
        int score;  //stores the total score
        Random rnd = new Random(); //random seed
        int rngb; //stores the number of the invader that is going to shoot a bullet.
        int redshipx = 800; //red ships x coordinate
        int redshipy = 60;
        int rngship;
        bool redship = false;

        int timing = 0; //stores how many 0.5 seconds there has been



        public Form1()
        {
            InitializeComponent();
            new Settings();
            Random rnd = new Random(); //random seed
            GameTimer.Interval = 1000/Settings.speed; // tick speed
            GameTimer.Tick += updateScreen; // linking the updateScreen function to the timer
            GameTimer.Start(); // starting the timer
            InvaderTimer.Interval = Settings.invaderspeed; // tick speed
            InvaderTimer.Tick += updateInvader; // linking the updateInvader function to the timer
            InvaderTimer.Start(); // starting the timer

            bullettimer.Interval = Settings.invaderspeed/16; // tick speed
            bullettimer.Tick += bulletUpdate; // linking the updateInvader function to the timer
            bullettimer.Start(); // starting the timer

            rngship = rnd.Next(30, 80); //randomly generates when the first red ship will appear 20,60

            // Create a timer and set a 0.5 second interval.
            aTimer = new System.Timers.Timer();
            aTimer.Interval = 500;
            // Hook up the Elapsed event for the timer. 
            aTimer.Elapsed += OnTimedEvent;
            // Have the timer fire repeated events (true is the default)
            aTimer.AutoReset = true;
            // Start the timer
            aTimer.Enabled = true;

            for (int i = 0; i < Shielddam.Length; i++)
            {
                Shielddam[i] = 4; //sets the damage of each section of the shield to 4
            }

        }

        private static System.Timers.Timer aTimer; //timer for counting seconds
        private void updateScreen(object sender, EventArgs e)
        {
            if (Settings.gamestart == false) //if the game hasn't started
            {
                pictureBox2.Invalidate(); //each tick refreshes this picturebox
            }
            // this is the Timers update screen function. 
            // each tick will run this function
            if (Settings.gamestart == true)
            {
                PBBack.Invalidate(); //refreshes the invaders screen evvery tick
               
                if (redship == true) //if redship is true
                {
                    if (redshipx < -70) //if redship reaches left of screen
                    {
                        RedshipO(); //red ship is gone
                    }
                    redshipx -= 1; //moves left each tick

                }
                
                PlayerMove(); //moves player 

                if (Settings.invadersleft == 0)
                {                    
                    Gameover();  //if all invaders are defeated, game is over
                }


                if (Settings.bullet == true)
                {
                    bullety -= Settings.bulletspeed; //bullet goes up each tick
                }
                else
                {
                    Bullet(); //loads new bullet
                }
                
            }
            

            
        }
        private void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
        {
            timing += 1; //every 0.5 seconds this goes up
            if (Settings.gamestart == true)
            {
                if (timing == rngship) //if the time elapsed matches the time the red ship should appear
                {
                    redship = true; //redship appears
                    redshipx = 800;
                }
            }
        }

        private void updateInvader(object sender, EventArgs e)  //timer that updates invader
        
        {
            if (Settings.gamestart == true)
            {
                              
                InvaderTimer.Interval = Settings.invaderspeed - (Settings.invaderspeed/Settings.invaderinc);  //updates the invaders update speed
                bullettimer.Interval = (Settings.invaderspeed /20)+35; //updates the bullets update speed

                InvaderMoving(); //invaders will move every tick

            }

        }
        private void bulletUpdate(object sender, EventArgs e)
        {
            if (Settings.gamestart == true)
            {
                rngb = rnd.Next(20 * Settings.invadersleft);  
                //generates number that gives 1/20 chance of a bullet being generated for each invader per tick

                for (int i = 0; i < invbully.Length; i++) //every bullet tick the bullets y coord increases
                {
                    invbully[i] += 5;  //all bullets move 5  
                }
            }
        }


        private void updateGraphics(object sender, PaintEventArgs e)
        { 

                // this is where we will see the invaders and player moving
                // draw invaders and stuff here

            Graphics canvas = e.Graphics; // create a new graphics class called canvas
            Point[] pnt = new Point[3];

            //draw player
            canvas.FillRectangle(Brushes.Lime, new Rectangle(
                                Settings.playerx,
                                Settings.playery,
                                Settings.shipsize, Settings.shipsize));

            canvas.FillRectangle(Brushes.Lime, new Rectangle(
                                Settings.playerx - Settings.shipsize,
                                Settings.playery + Settings.shipsize,
                                Settings.shipsize * 3, Settings.shipsize));

            //if theres a third life
            if (Settings.lives > 2)
            {
                canvas.FillRectangle(Brushes.Lime, new Rectangle(  //draw image
                    705,
                    20,
                    Settings.shipsize, Settings.shipsize));

                canvas.FillRectangle(Brushes.Lime, new Rectangle(
                                    705 - Settings.shipsize,
                                    20 + Settings.shipsize,
                                    Settings.shipsize * 3, Settings.shipsize));
            }
            //if theres a second life
            if (Settings.lives > 1)
            {
                canvas.FillRectangle(Brushes.Lime, new Rectangle(
                    655,
                    20,
                    Settings.shipsize, Settings.shipsize));

                canvas.FillRectangle(Brushes.Lime, new Rectangle(
                                    655 - Settings.shipsize,
                                    20 + Settings.shipsize,
                                    Settings.shipsize * 3, Settings.shipsize));
            }
            //if theres a life
            if (Settings.lives > 0)
            {
                canvas.FillRectangle(Brushes.Lime, new Rectangle(
                    605,
                    20,
                    Settings.shipsize, Settings.shipsize));

                canvas.FillRectangle(Brushes.Lime, new Rectangle(
                                    605 - Settings.shipsize,
                                    20 + Settings.shipsize,
                                    Settings.shipsize * 3, Settings.shipsize));
            }

            for (int s = 0; s < Shield.GetLength(0); s++) //goes through 2d array for shield
            {
                for (int d = 0; d < Shield.GetLength(1); d++)
                {
                    triangle = false; //sets triangle to false as defailt
                    Shieldindex = ((d * 10) + s); //generates the id this invader is 

                    if (Shielddam[Shieldindex] == 4)  //if the shield has no damage, this colour
                    {
                        Shieldcolour = Brushes.Lime;
                    }
                    if (Shielddam[Shieldindex] == 3) //if shield has taken 1 damage, this colour
                    {
                        Shieldcolour = Brushes.LimeGreen;
                    }
                    if (Shielddam[Shieldindex] == 2)
                    {
                        Shieldcolour = Brushes.ForestGreen;
                    }
                    if (Shielddam[Shieldindex] == 1)
                    {
                        Shieldcolour = Brushes.DarkGreen;
                    }

                    if (Shielddam[Shieldindex] != 0) //code for generating shield, only activates if shield not destroyed
                    {


                        switch (s) //case to change where the shield generates depending on its id.
                        {
                            case 0:
                                shieldx = 60;
                                shieldy = 400;  //bottom left shield
                                break;

                            case 1:
                                shieldx = 60;
                                shieldy = 385; //middle left shield
                                break;

                            case 2:
                                triangle = true;  //top triangle shield

                                pnt[0].X = 60 + d * 180;
                                pnt[0].Y = 385; //left corner

                                pnt[1].X = 80 + d * 180;  //bottom right corner
                                pnt[1].Y = 385;

                                pnt[2].X = 80 + d * 180;
                                pnt[2].Y = 370;  //top corner

                                trix = 60 + d * 180;
                                triy = 375;
                                break;

                            case 3:
                                triangle = true; //bottom left triangle shield

                                pnt[0].X = 80 + d * 180;
                                pnt[0].Y = 385; //top left corner

                                pnt[1].X = 80 + d * 180;  //bottom left corner
                                pnt[1].Y = 400;

                                pnt[2].X = 100 + d * 180;
                                pnt[2].Y = 385;  //right corner

                                trix = 80 + d * 180;
                                triy = 390;

                                break;

                            case 4:
                                shieldx = 80;
                                shieldy = 370;
                                break;

                            case 5:
                                shieldx = 100;
                                shieldy = 370;
                                break;

                            case 6:
                                triangle = true;

                                pnt[0].X = 120 + d * 180;
                                pnt[0].Y = 385; //left corner

                                pnt[1].X = 120 + d * 180;  //top left corner
                                pnt[1].Y = 370;

                                pnt[2].X = 140 + d * 180;
                                pnt[2].Y = 385;  //right corner

                                trix = 120 + d * 180;
                                triy = 375;

                                break;

                            case 7:
                                triangle = true;

                                pnt[0].X = 120 + d * 180;
                                pnt[0].Y = 385; //top right corner

                                pnt[1].X = 120 + d * 180;  //bottom right corner
                                pnt[1].Y = 400;

                                pnt[2].X = 100 + d * 180;
                                pnt[2].Y = 385;  //left corner

                                trix = 100 + d * 180;
                                triy = 390;

                                break;

                            case 8:
                                shieldx = 120;
                                shieldy = 385;
                                break;

                            case 9:
                                shieldx = 120;
                                shieldy = 400;
                                break;

                        }
                        if (triangle == false)
                        {
                            canvas.FillRectangle(Shieldcolour, new Rectangle( //draw shield
                            shieldx + d * 180, 
                            shieldy,
                            20, 15));

                            if (Settings.bullet == true) //if player bullet hits square shield
                            {
                                if ((bulletx + 4 > shieldx + d * 180) && (bulletx < (shieldx + d * 180) + 20) && (shieldy + 15 > bullety))
                                {
                                    Settings.bullet = false;
                                    Shielddam[Shieldindex] -= 1;
                                }
                            }

                            for (int i = 0; i < 50; i++) //for each invader bullet, if it hits a square shield
                            {
                                if (InBull[i] == true) //if there is a bullet
                                {
                                    if ((invbully[i] + 20 > shieldy) && (invbullx[i]+8 > shieldx + d * 180) && (invbullx[i] < (shieldx + d * 180)+20))                                        
                                    {
                                        InBull[i] = false; //bullet is gone
                                        Shielddam[Shieldindex] -= 1; //shield takes damage
                                    }
                                }
                            }
                        }
                        if (triangle == true) //if this part of the shield is a triangle
                        {
                            canvas.FillPolygon(Shieldcolour, pnt);  //draw triangle
                            
                            if (Settings.bullet == true) //if players bullet hits triangle
                            {
                                if ((bulletx + 4 > trix) && (bulletx < (trix) + 20) && (triy > bullety))
                                {
                                    Settings.bullet = false;  //bullet gone
                                    Shielddam[Shieldindex] -= 1; //shield takes damage
                                }
                            }

                            for (int i = 0; i < 50; i++) //for each invader bullet
                            {
                                if (InBull[i] == true)  //if it hits triangle shield
                                {
                                    if ((invbully[i] + 20 > triy) && (invbullx[i] + 8 > trix) && (invbullx[i] < (trix) + 20))
                                    {
                                        InBull[i] = false;           //bullet gone                              
                                        Shielddam[Shieldindex] -= 1;  //shield takes damage
                                    }
                                }
                            }
                            
                        }


                    }
                }
                if (redship == true)  //if a red ship has generated
                {
                    canvas.FillRectangle(Brushes.Red, new Rectangle(  //draw red ship
                    redshipx + Settings.shipsize * 2,
                    redshipy + Settings.shipsize * 2 - 4,
                    Settings.shipsize * 2 - 4, Settings.shipsize * 2 - 4));

                    canvas.FillRectangle(Brushes.Red, new Rectangle(
                    redshipx,
                    redshipy,
                    (Settings.shipsize * 6 - 4), Settings.shipsize * 2 - 4));

                    if ((bulletx + 4 > redshipx) && (bulletx < (redshipx+ (Settings.shipsize * 6 - 4))) && (bullety < redshipy + (Settings.shipsize * 4 - 8)) && (bullety+10 > redshipy))
                    { //if bullet hits red ship
                        RedshipO();  //red ship dies
                        pointsearned = rnd.Next(1, 5) * 50; //earn between 50-200 points
                        Score(); //score increases.  
                    }
                }

            }
                    //if the player has shot a bullet
                    if (Settings.bullet == true)
            {
                if (bullety > 0) //if the bullet has not reached the top of the screen
                {
                    canvas.FillRectangle(Brushes.Lime, new Rectangle(  //draw bullet
                        bulletx,
                        bullety,
                        4, 10
                        ));
                }
                else
                {
                    Settings.bullet = false; //if it has reached top, delete it
                    bulletx = Settings.playerx; //reset bullet coords
                    bullety = Settings.playery;
                }

            }

            for (int x = 0; x < Invaders.GetLength(0); x++)  //for each invader
            {
                for (int y = 0; y < Invaders.GetLength(1); y++)
                {

                    InvaderIndex = ((y * 10) + x); //which invader we are on.


                    if (InTrue[InvaderIndex] == false)  //if the invader exists still
                    {

                        colour = Brushes.White;   //its colour is white
                        pointsearned = 10;  //worth 10 points
                        if (y == 0)   
                        {
                            colour = Brushes.Purple;  //if its the top row, its purple and worth 40
                            pointsearned = 40;
                        }
                        if (y == 1 || y == 2)
                        {
                            colour = Brushes.Blue;  //if its the middle 2 rows, its blue and worth 20
                            pointsearned = 20;
                        }
                        
                        //draws each invader
                        canvas.FillRectangle(colour, new Rectangle(
                         Settings.invadermove + (x * Settings.shipsize * 4 + Settings.shipsize * 2),
                         currentinvadery = Settings.invadery + ((y * Settings.shipsize / 2 * 5) + Settings.shipsize * 3 - 2),
                                        Settings.shipsize - 2, Settings.shipsize - 2));

                        canvas.FillRectangle(colour, new Rectangle(
                            currentinvaderx = Settings.invadermove + (x * Settings.shipsize * 4 + Settings.shipsize),
                            Settings.invadery + ((y * Settings.shipsize / 2 * 5) + Settings.shipsize * 2),
                                            Settings.shipsize * 3 - 2, Settings.shipsize - 2));

                        if (Settings.gamestart == true)
                        {
                            if (InBull[InvaderIndex] == false)
                            {  //if this invader doesn't have a bullet
                                if (rngb == InvaderIndex) //if the bullet was generated on this invader
                                {
                                    InBull[InvaderIndex] = true;  //then this invader having a bullet is true
                                    invbully[InvaderIndex] = currentinvadery + Settings.shipsize; //the bullets coordinates
                                    invbullx[InvaderIndex] = currentinvaderx + Settings.shipsize;
                                }
                            }
                        }
                            //if invader reaches player y level
                            if ((currentinvadery + Settings.shipsize - 2) > Settings.playery)/* && (currentinvadery < (Settings.playery + Settings.shipsize*2)) && ((currentinvaderx) < (Settings.playerx + Settings.shipsize*3)) && ((currentinvaderx + Settings.shipsize * 3 - 2) > Settings.playerx))*/
                        {
                            Settings.gamestart = false; //game has stopped
                            Settings.lives = 0;  //all lives gone
                            Gameover(); //gameover runs
                        }


                        if (Settings.bullet == true)  //if player bullet hits invader
                        {
                            if (((currentinvadery + Settings.shipsize - 2) > bullety) && (currentinvadery < (bullety + 10)) && ((currentinvaderx) < (bulletx + 4)) && ((currentinvaderx + Settings.shipsize * 3 - 2) > bulletx))
                            {
                                InTrue[InvaderIndex] = true;  //invader is dead
                                Score(); //score increases
                                Settings.invadersleft -= 1; //one less invader
                            }

                        }
                    } 
                    if (InBull[InvaderIndex] == true)  //if this invader has a bullet
                    {
                        canvas.FillRectangle(Brushes.Red, new Rectangle(  //draw bullet
                                            invbullx[InvaderIndex],
                                            invbully[InvaderIndex],
                                            8, 20));
                        if (invbully[InvaderIndex] > 500) //if bullet reaches bottom of screen
                        {
                            InBull[InvaderIndex] = false; //bullet gone
                        }//if bullet hits player
                        if ((invbully[InvaderIndex] + 20 > Settings.playery) && (invbully[InvaderIndex] < Settings.playery + Settings.shipsize*2) && (invbullx[InvaderIndex] + 8> Settings.playerx-Settings.shipsize) && (invbullx[InvaderIndex] < Settings.playerx + Settings.shipsize*2)) 
                        {
                            InBull[InvaderIndex] = false; //bullet gone
                            LifeLoss();  //a life is lost
                        }
                        if (Settings.bullet == true) //if player has a bullet
                        {  //if bullet hits invaders bullet
                            if ((invbully[InvaderIndex] + 20 > bullety) /*&& (invbully[InvaderIndex] > bullety+10)*/ && (invbullx[InvaderIndex] < bulletx + 4) && (invbullx[InvaderIndex] + 8 > bulletx))
                            {
                                InBull[InvaderIndex] = false; //invader bullet is gone
                                Settings.bullet = false; //player bullet is gone
                            }
                        }
                    }

                }
            }
        }


        private void pictureBox2_Paint(object sender, PaintEventArgs e) //draws on picturebox2
        {
            Graphics canvasd = e.Graphics; // create a new graphics class called canvas

            if (Settings.gamestart == false)
            {
                if (timing > 0) //after 0.5 seconds
                {
                    canvasd.FillRectangle(Brushes.White, new Rectangle( //draw an invader on the title screen
                       245 + Settings.shipsize,
                       277 + Settings.shipsize - 2,
                        Settings.shipsize - 2, Settings.shipsize - 2));

                    canvasd.FillRectangle(Brushes.White, new Rectangle(
                    245,
                    277 ,
                        Settings.shipsize * 3 - 2, Settings.shipsize - 2));
                }

                if (timing > 1)
                {
                    label9.Visible = true; //label is visible
                }

                if (timing > 2)
                {
                    canvasd.FillRectangle(Brushes.Blue, new Rectangle(
                       245 + Settings.shipsize,
                       327 + Settings.shipsize - 2,
                        Settings.shipsize - 2, Settings.shipsize - 2));

                    canvasd.FillRectangle(Brushes.Blue, new Rectangle(
                    245,
                    327 ,
                        Settings.shipsize * 3 - 2, Settings.shipsize - 2));
                }
                if (timing > 3)
                {
                    label10.Visible = true;
                }

                if (timing > 4)
                {
                    canvasd.FillRectangle(Brushes.Purple, new Rectangle(
                       245 + Settings.shipsize,
                       377 + Settings.shipsize - 2,
                        Settings.shipsize - 2, Settings.shipsize - 2));

                    canvasd.FillRectangle(Brushes.Purple, new Rectangle(
                    245,
                    377,
                        Settings.shipsize * 3 - 2, Settings.shipsize - 2));
                }
                if (timing > 5)
                {
                    label11.Visible = true;
                }

                if (timing > 6)
                {
                    canvasd.FillRectangle(Brushes.Red, new Rectangle(
                       245 + Settings.shipsize,
                       427 + Settings.shipsize - 2,
                        Settings.shipsize - 2, Settings.shipsize - 2));

                    canvasd.FillRectangle(Brushes.Red, new Rectangle(
                    245,
                    427,
                        Settings.shipsize * 3 - 2, Settings.shipsize - 2));
                }
                if (timing > 7)
                {
                    label12.Visible = true;
                }
            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e) 
        {
            keydown = e.KeyCode; //stores the key pressed

            if (keydown == Keys.Escape) //if escape is pressed, exit application.  Essential code, always run
            {
                Application.Exit(); //exits application
            }

            if (Settings.gamestart == false)
            {
                if (keydown == Keys.Enter)  //if enter is pressed
                {
                    if (Settings.gameover == false) //if game hasn't started
                    {
                        StartGame(); //game starts
                    }
                    else 
                        RESET();  //application resets
                }
            }
            if (Settings.gamestart == true)
            {
                if (keydown == Keys.Space) //if space
                {
                    keyspace = true; 
                }
                if (keydown == Keys.Left)
                {
                    keyleft = true;
                }
                if (keydown == Keys.Right)
                {
                    keyright = true;

                }
            }

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            keyup = e.KeyCode;  //stores the recent key released
            if (keyup == Keys.Left)
            {
                keyleft = false;  //stops moving left
            }
            if (keyup == Keys.Right)
            {
                keyright = false; //stops moving right
            }
            if (keyup == Keys.Space)
            {
                keyspace = false;  //no longer fires if there is no bullet.  
            }
        }

        private void InvaderMoving()
        {
            if (Settings.invaderleft == false)  //if invaders aren't changing direction
            {
                Settings.invadermove += Settings.invaderright; //invaders move in current direction
            }

            if (Settings.invaderleft == true)  //if invaders are changing direction
            {
                Settings.invaderleft = false;  //invaders no longer changing direction
                Settings.invadery += Settings.shipsize*2 -4; //y coordinate increases
                Settings.invaderspeed = Settings.invaderspeed - (Settings.invaderspeed / Settings.invaderinc);  //invaders speed increases
                Settings.invaderright -= Settings.invaderright * 2; //invader reverses direction
            }

            if (Settings.invadermove > 270 && Settings.invaderright > 0)  //if invaders reach the right of screen
            {
                Settings.invadermove = 270;  //invaders are exactly here
                Settings.invaderleft = true;  //invaders now switch direction
            }
            if (Settings.invadermove < -15 && Settings.invaderright < 0) //if invaders reach left of screen
            {
                Settings.invadermove = -15;  //invaders move exactly here
                Settings.invaderleft = true;  //invaders change direction
            }

            PBBack.Invalidate();  //refreshes console
        }
        private void PlayerMove()
        {
            {
                if ((keyleft == true) && (Settings.playerx > Settings.shipsize)) //if its the left key
                {
                    Settings.playerx -= Settings.playerspeed;  //move left
                }
                if ((keyright == true) && (Settings.playerx < (735 - Settings.shipsize))) //if its the right key
                {
                    Settings.playerx += Settings.playerspeed;  //move right
                }
            }
        }
        private void Bullet()
        {
            if (keyspace == true) //if space has been pressed
            {
                Settings.bullet = true;  //bullet will now generate
                bulletx = Settings.playerx +3;  //bullets coords based on players current location
                bullety = Settings.playery;
            }
        }
        private void RedshipO() //when red ship no longer exists
        {
            redship = false; //red ship gone
            redshipx = 800; //x coordinate is back to 800
            rngship = rnd.Next(30, 80); //next red ship will appear at this time
            timing = 0; //timing is reset.  
        }
        private void StartGame()
        {
            Settings.gamestart = true;  //starts game
            pictureBox2.Visible = false;
            label2.Visible = false;  //hides title screen
            label3.Visible = false;
            label4.Visible = false;
            label9.Visible = false;
            label10.Visible = false; 
            label11.Visible = false;
            label12.Visible = false;
            timing = 0; //resets the timer for the redship 
        }
        private void Score()
        {
            Settings.bullet = false;  //bullet goes
            bulletx = Settings.playerx;  //bullet coords change
            bullety = Settings.playery;
            score += pointsearned;  //score increases
            Scored.Text = score.ToString();  //score textbox changes
            
            Settings.invaderspeed = Settings.invaderspeed - (Settings.invaderspeed / Settings.invaderinc*3);  //invaders speed increases
        }
        private void LifeLoss()
        {
            Settings.lives -= 1;  //life is lost
            if (Settings.lives == 0) //if no lore lives are left
            {
                Gameover(); //game over
            }
        }
        private void Gameover()
        {
            
            label8.Visible = true;  //shows gameover screen
            Winner.Visible = true;
            label5.Visible = true;
            label6.Visible = true;
            label7.Visible = true;
            pictureBox3.Visible = true;
            label6.Text = score.ToString(); //puts score on screen

            if (Settings.lives == 0)  //if you lost all your lives
            {
                Winner.Text = "You loose :(";
            }
            else
            {
                Winner.Text = "You win! :)";
            }
            Settings.gamestart = false; //game stops running
            Settings.gameover = true; //game will now be able to restart with enter key
        }

        private void RESET()
        {
            Application.Restart(); //restarts application

        }


        //rest is useless
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void PBBack_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }



        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
