﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Space_Invaders
{
    class Settings
    {
        public static bool gamestart { get; set; } // has the game started? 
        public static bool gameover { get; set; } // has the game started? 
        public static int speed { get; set; } // game tick speed
        public static int playerspeed { get; set; } // player movement speed
        public static int playerx { get; set; } // player x location
        public static int playery { get; set; } // player x location
        public static int shipsize { get; set; } // size of the square of the ship
        public static bool bullet { get; set; }
        public static int bulletspeed { get; set; }
        public static int lives { get; set; }

        public static int invaderspeed { get; set; } // game tick speed
        public static bool invaderbullet { get; set; }
        public static int invaderinc { get; set; }
        public static int invadermove { get; set; } // size of the square of the ship
        public static int invaderright { get; set; } // if the invader is moving right
        public static bool invaderleft { get; set; } // if the invader is moving right
        public static int invadery { get; set; } // if the invader is moving right

        public static int invadersleft { get; set; } // number of invaders left on the board

        public Settings()
        {
            speed = 100; //how fast the game updates
            gamestart = false; //if the game has started
            gameover = false; //if the game is over
            playerspeed = 4; //how fast the player moves.  Higher is faster
            playerx = 365; //players starting x coordinate
            playery = 430; //players starting y coordinate
            shipsize = 12; //size of player and invaders ships. 
            bullet = false; //if the player has shot a bullet
            bulletspeed = 4; //speed of bullet.  lower is slower
            lives = 3; //lives

            invadery = 90; //y coord the invaders start at
            invaderspeed = 2000; //update speed of invaders.  higher is slower.  
            invaderbullet = false; //if the invader is shooting a buller.  
            invaderinc = 45; //how fast the invader speed increases.  higher is slower
            invadermove = 125; //invaders x coordinate  
            invaderright = shipsize/2; //how far they move per tick
            invaderleft = false; //if the invader is currently changing direction
            invadersleft = 50; //how many invaders are left.  50 as game starts.  
        }
    }
}
